   
    <footer class="section p-3 bg-dark text-white">
        <div class="text-center">&copy;  Roin Copyright <?php echo date("Y"); ?> Aplikasi Pemesanan makanan</div>
    </footer>
</body>
</html>